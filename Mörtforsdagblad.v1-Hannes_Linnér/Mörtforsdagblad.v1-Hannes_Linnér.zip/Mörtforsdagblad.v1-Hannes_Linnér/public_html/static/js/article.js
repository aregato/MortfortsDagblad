$(function(){
  console.log("Hej");
});
