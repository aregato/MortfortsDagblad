All kod finns i public_html katalogen.

Projektet �r uppbyggt med Python ramverket Flask som backend.

Frontend delen best�r av Html, CSS och Javascript. 
Anv�nder designramverket Bootstrap tillsamman med JavaScriptramverket jQuery.

F�r att starta projektet beh�ver man installera alla pluggar till Python.
Sedan starta main filen f�r att k�ra ig�ng servern.

F�r att installera modulerna i Python.
 pip install flask
 pip install flask-login
 pip install psycopg2